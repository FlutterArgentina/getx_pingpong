class Point {
  double x;
  double y;

  Point({this.x, this.y});
}
